<?php
exit;
?>
;///////////////////////////////////////////////////////////////////////////////
;
; NagiosQL
;
;///////////////////////////////////////////////////////////////////////////////
;
; (c) 2008, 2009 by Martin Willisegger
;
; Project  : NagiosQL
; Component: Database Configuration
; Website  : http://www.nagiosql.org
; Date     : October 6, 2009, 9:53 pm
; Version  : 3.0.3
; Revision : $LastChangedRevision: 715 $
;
;///////////////////////////////////////////////////////////////////////////////
[db]
server       = localhost
port         = 3306
database     = nagiosql
username     = nagiosql
password     = n@gweb
[common]
install      = passed
