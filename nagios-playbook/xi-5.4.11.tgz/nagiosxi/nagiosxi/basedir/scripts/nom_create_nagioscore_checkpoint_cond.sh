#!/bin/bash
# Create a conditional NOM checkpoint
# Copyright (c) 2008-2016 Nagios Enterprises, LLC.  All rights reserved.

BASEDIR=$(dirname $(readlink -f $0))

/etc/init.d/nagios checkconfig
ret=$?


if [ $ret -eq 0 ]; then
    $BASEDIR/nom_create_nagioscore_checkpoint.sh
    echo "Config test passed.  Checkpoint created."
    exit 0
else
    echo "Config test failed.  Checkpoint aborted."
    exit 1
fi